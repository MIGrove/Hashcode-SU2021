class Car:
    def __init__(self, streets_count, streets_list):
        self.streetsCount = streets_count
        self.streets_list = streets_list
